@extends('admin.index')
@section('main_section')
<div class="main-content">

    <div class="page-content">
        <section class="content content-custom no-print">
            <div class=" content-wrapper " style="min-height: 306px;">
                <!-- empty div for vuejs -->

                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1> Employees <small>Manage your Employee</small>
                    </h1>
                </section>

                <!-- Main content -->
                <section class="content2">
                    <div class="box  box-solid " id="accordion">
                        <div class="box-header with-border" style="cursor: pointer;">
                            <h3 class="box-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapseFilter">
                                     Employee Login Details
                                </a>
                            </h3>
                        </div>
                        <div id="collapseFilter" class="panel-collapse active collapse  in "
                            aria-expanded="true">
                            <div class="box-body">
                                <div class="form-group">
                                <div class="col-md-12">
                                        <div class="col-md-6">
                                            <label for="" style="padding-left: 5px;"><strong>Full Name</strong></label>
                                            <input type="text" class="form-control" id="name" placeholder="" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="" style="padding-left: 5px;"><strong>Email</strong></label>
                                            <input type="text" class="form-control" id="name" placeholder="" required>
                                        </div>
                                </div>
                                <div class="col-md-12 pt-3">
                                    <div class="col-md-6">
                                        <label for="" style="padding-left: 5px;"><strong>Mobile No</strong></label>
                                        <input type="text" class="form-control" id="name" placeholder="" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="" ><strong>Role</strong></label>
                                        <select name="role" id="" class="form-select p-3">
                                            <option value="">select Role</option>
                                            {{ role(3); }}
                                        </select>

                                    </div>
                            </div>


                            </div>
                        </div>
                    </div>



                </section>
                <!-- /.content -->




                <!-- This will be printed -->


            </div>

        </section>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->




    <!-- <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <script>document.write(new Date().getFullYear())</script> © Skote.
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        Design & Develop by Dignexus
                    </div>
                </div>
            </div>
        </div>
    </footer> -->
</div>
@endsection
